import React from "react";
import MainLayout from "./layout/MainLayout";

const App = () => {
  return <MainLayout />;
};

export default App;